AI Patrols are set for Duga Airfield, Red Forest Reactor and Chernobyl
- if you wish to add more ai patrols COPY THE LAST PATROL IN THE FILE AND PASTE IT UNDERNEATH AND JUST CHANGE TO COORDS

Market file has spawn points at respective traders for vehicles, boats and aircraft

Safezone is currently set to the flee market but can be easily changed or duplicated