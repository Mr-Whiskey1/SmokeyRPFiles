these files hanlde the spawning of items 
-the types file in this case only gives lifetime
-if you want to adjust the amount of nodes spawning then edit the miningsystem_events file

-the vanilla cfgeventspawns file contains the node spawn points edit these points to change where they spawn