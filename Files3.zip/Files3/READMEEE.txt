Add the serverMission.pripyat to your mpMissions folder

start the server when youve added it and all the mods 

once the server has produced the files go into sss EditorFiles sss and copy the  "entername.dze" file into your mpmissions -> EditorFiles folder