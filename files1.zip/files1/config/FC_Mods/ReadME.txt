FC_Fish_Equip_config

-this file basically sets what fish or items you will catch in the water
