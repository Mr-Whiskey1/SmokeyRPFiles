Only touch the Spawn Selection to edit spawn points 

Spawn settings isnt important