Inside each of these folder are various files...

AI
-DO NOT TOUCH THIS WITHOUT HELP IT WILL RUIN EVERYTHING

ATM
-Creats LOGs of players atm accounts

Loadouts
- As it suggest this is your loadout folder
-you can edit each loadout to your liking
-All these do is set the AI loadouts nothing more
- if you dont have custom spawn gear setup then players will use male or female survivor loadouts

Market
-these files are the "categories" for your traders 
example:
A weapons trader will have the categories:
Assault Rifles
Pistols
RIfles
Shotguns
Sniper rifles

Inside each of these files is what is included in that category

Quests
-here is where you will setup your quests 
-i Reccomend leaving the NPCs alone
Check the Github for exansion mod on how to set these up better

Settings
- Airdrop Settings
	-Controls what containers spawn and what they have in them
	
-AISettings
	-All thats important for you is to set admins so they AI wont kill you (i think)
	
-General Settings
	-Used to setup Death Screen, Unlimited Stamina, AutoRun and a few other Info items

-Mission Settings
	-Allows you to set the ammount of missions and how many people need to be on server to start missions
	
-the other settings in this file are pretty self explanitory 

Traders File:
-These are the different types of traders 
-the only reason to edit these files is to add more categories to each trader 
or
- if you set up another trader area in mpmission -> pripyat -> Expansion -> trader
then youd add that trader type here and add its categories then go to market to edit what you want this trader to sell