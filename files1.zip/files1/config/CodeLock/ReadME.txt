Code Lock Config:
-Allows gate placement/raid
-allows tent placement/raid
-what happens when codelock is raided

CodeLockPerms
-Can set who can use codelocks
-More of a whitelist type of file

MSPCodeLockConfig
-Attach to MSP items (y/n)
-Raidable (y/n)
-rest is same as "CodeLock Config"