the top few lines Handles what the Recycle Machine produces

The Grades at the bottom handle what is printed 
Grade 1 is low tier loot 
Grade 4 is highest tier lootSet to whatever you want

-Grade 1 Requires only one fillament
-Grade 4 requires 4 Fillament
Printing us single use so if you print a grade 4 item 10 then it uses all four fillaments so you will need to find more before printing again