Open this The "Example" File
grab your steam64id
save as "yoursteam64id.json" without the parentheses ""
Use your steam64ID not "yoursteam64id"
delete this text document