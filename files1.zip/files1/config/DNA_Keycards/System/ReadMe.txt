Inside the system file ar various configs that handle crate and stronghold spawning
-Loot crate spawning
each file is well explained via comments on the file itself (youll see what im talking about in the file)
(Again join their discord)