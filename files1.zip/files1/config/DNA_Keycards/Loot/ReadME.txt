In each file (clothing, General, other, Weapons) allows you to set the tier and loot in each "tier stronghold"

Inside Other file there are files called SMOL_color_config
These are for the SMOL crates you can find around the map if you have them spawn in
(reccomend you join DNA discord for more help on this mod)