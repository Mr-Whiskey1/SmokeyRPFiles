Loot
- Handles what spawns in crates

mapname (Pripyat)
Handles what zombies spawn around Loot
Uses heli crash spawn for some reason
Again id join their discord for more info
