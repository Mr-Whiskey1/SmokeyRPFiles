Edit the BBP_settings to your liking
raid tools for tier 1-4 is just like vanilla raiding.
explosives will still blow the door so no need to add them
By default ive set base raiding to door only so walls will not take damage 