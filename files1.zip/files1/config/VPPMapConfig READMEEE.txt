USe this To set server markers as well
-Will show up in the stalker PDA 